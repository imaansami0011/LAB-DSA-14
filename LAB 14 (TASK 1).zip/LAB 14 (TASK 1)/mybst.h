#include<iostream>
#include"node.h"

class mybst
{
protected:
	
	node* root;
	node* insert(node* root,int val)
	{
		if (root == nullptr)
		{
			return new node(val);
		}

		if (val < root->data)
		{
			root->left = insert(root->left, val);
		}
		else if (val > root->data)
		{
			root->right = insert(root->right, val);
		}
		return root;
	}


	node* findmin(node* temp)
	{
		while (temp->left != nullptr)
		{
			temp = temp->left;
		}
		return temp;
	}


	node* deletenode(node* root, int val)
	{
		if (root == nullptr)
		{
			return 0;
		}
		if (val < root->data)
		{
			root->left = deletenode(root->left, val);
		}
		else if (val > root->data)
		{
			root->right = deletenode(root->right, val);
		}
		else
		{
			if (root->left == nullptr && root->right==nullptr)
			{
				delete root;
				return nullptr;

			}
			else if (root->left == nullptr)
			{
				node* temp = root->right;
				delete root;
				return temp;
			}
			else if (root->right == nullptr)
			{
				node* temp = root->left;
				delete root;
				return temp;
			}
			else
			{
				node* t = findmin(root->right);
				root->data = t->data;
				root->right = deletenode(root->right, t->data);
			}
		}
		return root;
	}


	void inorder(node* n)
	{
		if (n == nullptr)
		{
			return;
		}
		inorder(n->left);
		cout << "Value: " << n->data << endl;
	
		inorder(n->right);
	}


public:
	mybst():root(nullptr){}


	//insert
	void insertvalue(int val)
	{
		root = insert(root, val);
	}

	//delete
	void deletevalue(int val)
	{
		root = deletenode(root, val);
	}

	//inorder
	void display()
	{
		inorder(root);
	}
};