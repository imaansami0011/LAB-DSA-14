
#include<iostream>
using namespace std;

struct node
{
	int data;
	node* right;
	node* left;
	
	node(int val)
	{
		data = val;
		left = nullptr;
		right = nullptr;
	}
};



