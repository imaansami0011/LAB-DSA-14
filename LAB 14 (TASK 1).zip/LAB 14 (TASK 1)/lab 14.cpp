#include "mybst.h"

int main()
{
	mybst tree;

	cout << "Inserted Values In BST Before Deletion: " << endl;
	cout << "-----------------------" << endl;
	tree.insertvalue(50);
	tree.insertvalue(30);
	tree.insertvalue(70);
	tree.insertvalue(20);
	tree.insertvalue(40);
	tree.insertvalue(60);
	tree.insertvalue(80);

	tree.display();
	cout << endl;

	int d;
	cout << "Enter The Value You Want To Delete: " << endl;
	cin >> d;
	tree.deletevalue(d);
	cout << endl;


	cout << " Values In BST After Deletion: " << endl;
	cout << "-----------------------" << endl;
	tree.display();


	return 0;




}